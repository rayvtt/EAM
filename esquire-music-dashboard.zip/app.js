// Global state
let currentTheme = 'light';
let currentWeek = new Date();
let currentMonth = new Date();

// Data from the provided JSON
let articlesData = [
    {
        id: 1,
        title: "The Rise of AI in Music Production",
        author: "Sarah Martinez",
        type: "Feature Story",
        status: "Draft",
        priority: 8,
        wordCount: 1200,
        targetWords: 1500,
        deadline: "2025-06-15",
        assignedDate: "2025-06-01",
        socialMediaPotential: 9
    },
    {
        id: 2,
        title: "Taylor Swift's Latest Album Review",
        author: "Mike Johnson",
        type: "Album Review",
        status: "Review",
        priority: 9,
        wordCount: 800,
        targetWords: 800,
        deadline: "2025-06-10",
        assignedDate: "2025-05-28",
        socialMediaPotential: 10
    },
    {
        id: 3,
        title: "Underground Hip-Hop Scene in Brooklyn",
        author: "Alex Chen",
        type: "Cultural Analysis",
        status: "Editing",
        priority: 7,
        wordCount: 2200,
        targetWords: 2000,
        deadline: "2025-06-20",
        assignedDate: "2025-05-25",
        socialMediaPotential: 8
    },
    {
        id: 4,
        title: "Interview with Billie Eilish",
        author: "Emma Wilson",
        type: "Artist Interview",
        status: "Published",
        priority: 10,
        wordCount: 1800,
        targetWords: 1800,
        deadline: "2025-05-30",
        assignedDate: "2025-05-15",
        socialMediaPotential: 10
    },
    {
        id: 5,
        title: "Best Summer Music Festivals 2025",
        author: "David Rodriguez",
        type: "Best Of Lists",
        status: "Assigned",
        priority: 6,
        wordCount: 0,
        targetWords: 1200,
        deadline: "2025-06-25",
        assignedDate: "2025-06-01",
        socialMediaPotential: 8
    }
];

let socialMediaData = [
    {
        id: 1,
        platform: "Instagram",
        type: "Post",
        content: "Behind the scenes of our Billie Eilish interview",
        scheduledDate: "2025-06-02",
        status: "Scheduled",
        linkedArticle: 4,
        engagement: 0
    },
    {
        id: 2,
        platform: "TikTok",
        type: "Video",
        content: "Quick take on AI in music production",
        scheduledDate: "2025-06-05",
        status: "Draft",
        linkedArticle: 1,
        engagement: 0
    },
    {
        id: 3,
        platform: "Instagram",
        type: "Story",
        content: "Brooklyn hip-hop scene highlights",
        scheduledDate: "2025-06-03",
        status: "Scheduled",
        linkedArticle: 3,
        engagement: 0
    }
];

const contentTypes = [
    "Album Review",
    "Artist Interview", 
    "Live Performance Review",
    "Music News/Breaking",
    "Feature Story",
    "Cultural Analysis",
    "Industry Trends",
    "Best Of Lists",
    "Emerging Artist Spotlight",
    "Music History/Retrospective"
];

const statuses = [
    "Idea",
    "Pitched", 
    "Assigned",
    "Draft",
    "Review",
    "Editing",
    "Final",
    "Published"
];

const platforms = ["Instagram", "TikTok"];
const postTypes = ["Post", "Story", "Reel", "Video"];

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupNavigation();
    populateMetrics();
    populateActivityFeed();
    populateDeadlineList();
    populateArticlePipeline();
    populateSocialCalendar();
    populateMonthlyCalendar();
    initializeCharts();
    populateFormOptions();
    setupSearch();
    updateLastSync();
    
    // Set initial theme
    applyTheme(currentTheme);
    
    // Setup drag and drop after pipeline is populated
    setTimeout(() => {
        setupDragAndDrop();
    }, 100);
}

// Navigation
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.content-section');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Update active nav link
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding section
            const targetSection = this.dataset.section;
            sections.forEach(section => {
                section.classList.remove('active');
            });
            document.getElementById(targetSection).classList.add('active');
            
            // Refresh charts when switching to analytics
            if (targetSection === 'analytics') {
                setTimeout(() => {
                    initializeCharts();
                }, 100);
            }
        });
    });
}

// Theme Toggle
function toggleTheme() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(currentTheme);
}

function applyTheme(theme) {
    document.body.setAttribute('data-color-scheme', theme);
    const themeIcon = document.querySelector('.theme-toggle i');
    themeIcon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
}

// Metrics
function populateMetrics() {
    const inProgress = articlesData.filter(article => 
        !['Published'].includes(article.status)
    ).length;
    
    const publishedThisMonth = articlesData.filter(article => 
        article.status === 'Published'
    ).length;
    
    const socialScheduled = socialMediaData.filter(post => 
        post.status === 'Scheduled'
    ).length;
    
    const deadlinesThisWeek = articlesData.filter(article => {
        const deadline = new Date(article.deadline);
        const today = new Date();
        const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
        return deadline >= today && deadline <= nextWeek;
    }).length;
    
    document.getElementById('articles-in-progress').textContent = inProgress;
    document.getElementById('published-this-month').textContent = publishedThisMonth;
    document.getElementById('social-posts-scheduled').textContent = socialScheduled;
    document.getElementById('deadlines-this-week').textContent = deadlinesThisWeek;
}

// Activity Feed
function populateActivityFeed() {
    const feed = document.getElementById('activity-feed');
    const activities = [
        { icon: 'fas fa-edit', title: 'Article Updated', desc: 'Sarah updated "AI in Music Production"', time: '2 minutes ago' },
        { icon: 'fas fa-check', title: 'Article Published', desc: 'Billie Eilish interview went live', time: '1 hour ago' },
        { icon: 'fas fa-calendar', title: 'Social Post Scheduled', desc: 'Instagram post for tomorrow', time: '3 hours ago' },
        { icon: 'fas fa-user-plus', title: 'New Assignment', desc: 'David assigned festival article', time: '1 day ago' }
    ];
    
    feed.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-icon">
                <i class="${activity.icon}"></i>
            </div>
            <div class="activity-content">
                <h4>${activity.title}</h4>
                <p>${activity.desc} • ${activity.time}</p>
            </div>
        </div>
    `).join('');
}

// Deadline List
function populateDeadlineList() {
    const list = document.getElementById('deadline-list');
    const today = new Date();
    
    const upcomingDeadlines = articlesData
        .filter(article => new Date(article.deadline) >= today && article.status !== 'Published')
        .sort((a, b) => new Date(a.deadline) - new Date(b.deadline))
        .slice(0, 5);
    
    list.innerHTML = upcomingDeadlines.map(article => {
        const deadline = new Date(article.deadline);
        const daysUntil = Math.ceil((deadline - today) / (1000 * 60 * 60 * 24));
        const urgency = daysUntil <= 2 ? 'urgent' : daysUntil <= 7 ? 'soon' : '';
        
        return `
            <div class="deadline-item">
                <div class="deadline-info">
                    <h4>${article.title}</h4>
                    <p>by ${article.author}</p>
                </div>
                <div class="deadline-badge deadline-${urgency}">
                    ${daysUntil} day${daysUntil !== 1 ? 's' : ''}
                </div>
            </div>
        `;
    }).join('');
}

// Article Pipeline
function populateArticlePipeline() {
    const pipeline = document.getElementById('article-pipeline');
    
    pipeline.innerHTML = statuses.map(status => {
        const statusArticles = articlesData.filter(article => article.status === status);
        
        return `
            <div class="pipeline-column" data-status="${status}">
                <div class="pipeline-header">
                    <h3>${status}</h3>
                    <div class="pipeline-count">${statusArticles.length}</div>
                </div>
                <div class="pipeline-articles">
                    ${statusArticles.map(article => createArticleCard(article)).join('')}
                </div>
            </div>
        `;
    }).join('');
}

function createArticleCard(article) {
    const progress = (article.wordCount / article.targetWords) * 100;
    const priorityClass = article.priority >= 8 ? 'high' : article.priority >= 5 ? 'medium' : 'low';
    
    return `
        <div class="article-card" draggable="true" data-article-id="${article.id}">
            <h4>${article.title}</h4>
            <div class="article-meta">
                <span>${article.author}</span>
                <span class="priority-badge priority-${priorityClass}">P${article.priority}</span>
            </div>
            <div class="article-meta">
                <span>${article.type}</span>
                <span>${new Date(article.deadline).toLocaleDateString()}</span>
            </div>
            <div class="word-progress">
                <div class="word-progress-bar" style="width: ${Math.min(progress, 100)}%"></div>
            </div>
            <div style="font-size: 11px; color: var(--color-text-secondary); margin-top: 4px;">
                ${article.wordCount}/${article.targetWords} words
            </div>
        </div>
    `;
}

// Social Media Calendar
function populateSocialCalendar() {
    const grid = document.getElementById('social-calendar-grid');
    const startOfWeek = new Date(currentWeek);
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
    
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    let calendarHTML = '';
    
    // Day headers
    days.forEach(day => {
        calendarHTML += `<div class="calendar-day-header">${day}</div>`;
    });
    
    // Days with posts
    for (let i = 0; i < 7; i++) {
        const date = new Date(startOfWeek);
        date.setDate(date.getDate() + i);
        
        const dayPosts = socialMediaData.filter(post => {
            const postDate = new Date(post.scheduledDate);
            return postDate.toDateString() === date.toDateString();
        });
        
        calendarHTML += `
            <div class="calendar-day">
                <div class="calendar-day-number">${date.getDate()}</div>
                <div class="social-posts">
                    ${dayPosts.map(post => `
                        <div class="social-post-indicator ${post.platform.toLowerCase()}-post" 
                             title="${post.content}"></div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    grid.innerHTML = calendarHTML;
    document.getElementById('current-week').textContent = `Week of ${startOfWeek.toLocaleDateString()}`;
}

// Monthly Calendar
function populateMonthlyCalendar() {
    const grid = document.getElementById('monthly-calendar-grid');
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());
    
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    let calendarHTML = '';
    
    // Day headers
    days.forEach(day => {
        calendarHTML += `<div class="calendar-day-header">${day}</div>`;
    });
    
    // Calendar days
    for (let i = 0; i < 42; i++) {
        const date = new Date(startDate);
        date.setDate(date.getDate() + i);
        
        const isCurrentMonth = date.getMonth() === month;
        const dayArticles = articlesData.filter(article => {
            const deadline = new Date(article.deadline);
            return deadline.toDateString() === date.toDateString();
        });
        
        calendarHTML += `
            <div class="monthly-day ${!isCurrentMonth ? 'other-month' : ''}">
                <div class="monthly-day-number">${date.getDate()}</div>
                ${dayArticles.map(article => `
                    <div class="calendar-event" title="${article.title}">
                        ${article.title.substring(0, 20)}${article.title.length > 20 ? '...' : ''}
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    grid.innerHTML = calendarHTML;
    document.getElementById('current-month').textContent = 
        currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

// Charts
function initializeCharts() {
    initializeEngagementChart();
    initializeCompletionChart();
    initializePriorityChart();
    initializeContentTypesChart();
    initializeProductivityChart();
}

function initializeEngagementChart() {
    const ctx = document.getElementById('engagement-chart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Instagram',
                data: [12, 19, 15, 25, 22, 30, 28],
                borderColor: '#1FB8CD',
                backgroundColor: 'rgba(31, 184, 205, 0.1)',
                tension: 0.4
            }, {
                label: 'TikTok',
                data: [8, 15, 12, 20, 18, 25, 22],
                borderColor: '#FFC185',
                backgroundColor: 'rgba(255, 193, 133, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Engagement Rate (%)'
                    }
                }
            }
        }
    });
}

function initializeCompletionChart() {
    const ctx = document.getElementById('completion-chart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Completed', 'In Progress', 'Not Started'],
            datasets: [{
                data: [40, 45, 15],
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function initializePriorityChart() {
    const ctx = document.getElementById('priority-chart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['High (8-10)', 'Medium (5-7)', 'Low (1-4)'],
            datasets: [{
                label: 'Articles',
                data: [3, 1, 1],
                backgroundColor: ['#B4413C', '#FFC185', '#1FB8CD']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Articles'
                    }
                }
            }
        }
    });
}

function initializeContentTypesChart() {
    const ctx = document.getElementById('content-types-chart');
    if (!ctx) return;
    
    const typeCounts = {};
    articlesData.forEach(article => {
        typeCounts[article.type] = (typeCounts[article.type] || 0) + 1;
    });
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(typeCounts),
            datasets: [{
                data: Object.values(typeCounts),
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function initializeProductivityChart() {
    const ctx = document.getElementById('productivity-chart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Sarah M.', 'Mike J.', 'Alex C.', 'Emma W.', 'David R.'],
            datasets: [{
                label: 'Articles This Month',
                data: [1, 1, 1, 1, 1],
                backgroundColor: '#1FB8CD'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Articles Completed'
                    }
                }
            }
        }
    });
}

// Form Population
function populateFormOptions() {
    // Content types for article form
    const typeSelects = document.querySelectorAll('select[name="type"]');
    typeSelects.forEach(select => {
        select.innerHTML = contentTypes.map(type => 
            `<option value="${type}">${type}</option>`
        ).join('');
    });
    
    // Article filter
    const filterSelect = document.getElementById('article-filter');
    if (filterSelect) {
        filterSelect.innerHTML = '<option value="">All Types</option>' + 
            contentTypes.map(type => `<option value="${type}">${type}</option>`).join('');
    }
    
    // Linked articles for social posts
    const linkedArticleSelects = document.querySelectorAll('select[name="linkedArticle"]');
    linkedArticleSelects.forEach(select => {
        select.innerHTML = '<option value="">None</option>' + 
            articlesData.map(article => 
                `<option value="${article.id}">${article.title}</option>`
            ).join('');
    });
}

// Search Functionality
function setupSearch() {
    const searchInput = document.getElementById('article-search');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const articleCards = document.querySelectorAll('.article-card');
            
            articleCards.forEach(card => {
                const title = card.querySelector('h4').textContent.toLowerCase();
                const author = card.querySelector('.article-meta span').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || author.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
}

// Enhanced Drag and Drop
function setupDragAndDrop() {
    let draggedElement = null;
    
    // Add event listeners to all existing article cards
    function addDragListeners() {
        const articleCards = document.querySelectorAll('.article-card');
        articleCards.forEach(card => {
            card.addEventListener('dragstart', handleDragStart);
            card.addEventListener('dragend', handleDragEnd);
        });
        
        const columns = document.querySelectorAll('.pipeline-column');
        columns.forEach(column => {
            column.addEventListener('dragover', handleDragOver);
            column.addEventListener('drop', handleDrop);
            column.addEventListener('dragenter', handleDragEnter);
            column.addEventListener('dragleave', handleDragLeave);
        });
    }
    
    function handleDragStart(e) {
        draggedElement = this;
        this.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
    }
    
    function handleDragEnd(e) {
        this.classList.remove('dragging');
        draggedElement = null;
        
        // Remove all drag-over classes
        document.querySelectorAll('.pipeline-column').forEach(col => {
            col.classList.remove('drag-over');
        });
    }
    
    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
    }
    
    function handleDragEnter(e) {
        e.preventDefault();
        this.classList.add('drag-over');
    }
    
    function handleDragLeave(e) {
        // Only remove drag-over if we're actually leaving the column
        if (!this.contains(e.relatedTarget)) {
            this.classList.remove('drag-over');
        }
    }
    
    function handleDrop(e) {
        e.preventDefault();
        this.classList.remove('drag-over');
        
        if (draggedElement) {
            const newStatus = this.dataset.status;
            const articleId = parseInt(draggedElement.dataset.articleId);
            
            // Update article status
            const article = articlesData.find(a => a.id === articleId);
            if (article && article.status !== newStatus) {
                article.status = newStatus;
                
                // Repopulate the pipeline
                populateArticlePipeline();
                populateMetrics();
                
                // Re-setup drag and drop for new elements
                setTimeout(() => {
                    addDragListeners();
                }, 50);
                
                showMessage(`Article moved to ${newStatus} successfully!`, 'success');
            }
        }
    }
    
    // Initialize drag listeners
    addDragListeners();
}

// Modal Functions
function showAddArticleModal() {
    document.getElementById('add-article-modal').classList.add('active');
}

function showAddSocialPostModal() {
    document.getElementById('add-social-post-modal').classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Add Article
function addArticle() {
    const form = document.getElementById('add-article-form');
    const formData = new FormData(form);
    
    const newArticle = {
        id: Math.max(...articlesData.map(a => a.id)) + 1,
        title: formData.get('title'),
        author: formData.get('author'),
        type: formData.get('type'),
        status: 'Idea',
        priority: parseInt(formData.get('priority')),
        wordCount: 0,
        targetWords: parseInt(formData.get('targetWords')),
        deadline: formData.get('deadline'),
        assignedDate: new Date().toISOString().split('T')[0],
        socialMediaPotential: Math.floor(Math.random() * 5) + 6
    };
    
    articlesData.push(newArticle);
    populateArticlePipeline();
    populateMetrics();
    
    // Re-setup drag and drop for new elements
    setTimeout(() => {
        setupDragAndDrop();
    }, 50);
    
    closeModal('add-article-modal');
    form.reset();
    showMessage('Article added successfully!', 'success');
}

// Add Social Post
function addSocialPost() {
    const form = document.getElementById('add-social-post-form');
    const formData = new FormData(form);
    
    const newPost = {
        id: Math.max(...socialMediaData.map(p => p.id)) + 1,
        platform: formData.get('platform'),
        type: formData.get('type'),
        content: formData.get('content'),
        scheduledDate: formData.get('scheduledDate'),
        status: 'Scheduled',
        linkedArticle: formData.get('linkedArticle') ? parseInt(formData.get('linkedArticle')) : null,
        engagement: 0
    };
    
    socialMediaData.push(newPost);
    populateSocialCalendar();
    closeModal('add-social-post-modal');
    form.reset();
    showMessage('Social media post scheduled successfully!', 'success');
}

// Calendar Navigation
function previousWeek() {
    currentWeek.setDate(currentWeek.getDate() - 7);
    populateSocialCalendar();
}

function nextWeek() {
    currentWeek.setDate(currentWeek.getDate() + 7);
    populateSocialCalendar();
}

function previousMonth() {
    currentMonth.setMonth(currentMonth.getMonth() - 1);
    populateMonthlyCalendar();
}

function nextMonth() {
    currentMonth.setMonth(currentMonth.getMonth() + 1);
    populateMonthlyCalendar();
}

// Google Sheets Integration
function syncGoogleSheets() {
    const button = event.target;
    button.classList.add('loading');
    button.textContent = 'Syncing...';
    
    setTimeout(() => {
        button.classList.remove('loading');
        button.innerHTML = '<i class="fas fa-sync"></i> Sync Now';
        updateLastSync();
        showMessage('Google Sheets synced successfully!', 'success');
    }, 2000);
}

function updateLastSync() {
    document.getElementById('last-sync').textContent = 'Just now';
}

// Export Functions
function exportCalendar() {
    showMessage('Calendar exported successfully!', 'success');
}

function exportReport() {
    showMessage('Report exported successfully!', 'success');
}

function exportData(format) {
    showMessage(`Data exported as ${format.toUpperCase()} successfully!`, 'success');
}

function backupData() {
    showMessage('Data backed up to cloud successfully!', 'success');
}

// Utility Functions
function showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message--${type}`;
    messageDiv.textContent = message;
    
    const container = document.querySelector('.main-content');
    container.insertBefore(messageDiv, container.firstChild);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}

// Close modals when clicking outside
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});